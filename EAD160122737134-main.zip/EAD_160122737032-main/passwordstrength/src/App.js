import "./App.css";
import React from "react";
import { useState } from "react";
import PassCheck from "./components/PassCheck";

function App() {
  return (
    <>
      <PassCheck />
    </>
  );
}

export default App;
